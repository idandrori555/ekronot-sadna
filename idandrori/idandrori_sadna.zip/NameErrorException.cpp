#include "NameErrorException.h"

const char *NameErrorException::what(void) const noexcept
{
  return ("NameError: name " + _name + " is not defined").c_str();
};
