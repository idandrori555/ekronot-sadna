#pragma once

constexpr const char *TRUE_STR = "True";
constexpr const char *FALSE_STR = "False";

constexpr const char NEW_LINE = '\n';
constexpr const char SPACE = ' ';
constexpr const char TAB = '\t';

constexpr const char *WELCOME = "Welcome to Magshimim Python Interperter version 1.0 by ";
constexpr const char *YOUR_NAME = "Idan Drori";

constexpr const char UNDERSCORE = '_';

constexpr const char EQUAL_SIGN = '=';
