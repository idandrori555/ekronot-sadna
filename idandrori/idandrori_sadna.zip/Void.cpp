#include "Void.h"

bool Void::isPrintable(void) const
{
  return false;
}

std::string Void::toString(void) const
{
  return "";
};
